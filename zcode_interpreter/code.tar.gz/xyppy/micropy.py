from xyppy.blorb import *
from xyppy.debug import *
from xyppy.iff import *
from xyppy.ops_decode import *
from xyppy.ops_impl_compat import *
from xyppy.ops_impl import *
from xyppy.ops import *
from xyppy.quetzal import *
from xyppy.zenv import *
from xyppy.zmath import *
#from xyppy.zork import *
#import ubinascii


f = open("zork_1.z5", "rb")
mem = f.read()
#mem = ubinascii.a2b_base64(game_data) 

env = Env(mem, None)

#term.init(env)
#env.screen.first_draw()
ops.setup_opcodes(env)
while True:
	step(env)
step(env)
step(env)
