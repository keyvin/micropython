# os-specific txt controls


import ctypes
import sys
import time

from collections import deque

from xyppy.debug import err, warn

win_original_attributes = None
win_original_cursor_info = None

unix_in_tstp_signal = False
unix_screen_is_reset = False

stdin_is_tty = sys.stdin.isatty()
stdout_is_tty = sys.stdout.isatty()

def init(env):
        if stdin_is_tty:
            stdin_fd = sys.stdin.fileno()
            orig = termios.tcgetattr(stdin_fd)
            atexit.register(lambda: termios.tcsetattr(stdin_fd, termios.TCSAFLUSH, orig))
            tty.setcbreak(stdin_fd)

def eat_char_loop():
    global stored_chars
    while True:
        if len(stored_chars) < 32 and not unix_in_tstp_signal:
            # safe, b/c only one thread pushes
            stored_chars.append(getch_impl())
        else:
            time.sleep(0.005)
def start_char_loop_thread():
    t = Thread(target=eat_char_loop, args=[])
    t.daemon = True
    t.start()

used_esc_char_list = [
    # arrow keys
    '[A', '[B', '[C', '[D',
    # fkeys
    'OP', 'OQ', 'OR', 'OS', '[15~', '[17~',
    '[18~', '[19~', '[20~', '[21~', '[23~', '[24~',
]
non_zscii_esc_char_list = [
    # home/end
    '[H', '[F',
    # ins/del, pgup/pgdn, alt home/end
    '[2~', '[3~', '[5~', '[6~', '[1~', '[4~',
]
esc_char_list = used_esc_char_list + non_zscii_esc_char_list
def could_be_escape(seq):
    return any(x.startswith(seq) for x in esc_char_list)
def is_zscii_special_key(seq):
    return seq[0] == '\x1b' and seq[1:] in used_esc_char_list

def puts(s):
    sys.stdout.write(s)
    sys.stdout.flush()

def flush():
    sys.stdout.flush()
